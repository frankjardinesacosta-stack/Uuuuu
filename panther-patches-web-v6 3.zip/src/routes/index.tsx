import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Crosshair, TriangleAlert, X } from "lucide-react";
import bg from "@/assets/patches-background.jpeg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aimbot — Panther Patches" },
      { name: "description", content: "Toggle your Aim, Texture, Holo Arma and Settings patches." },
      { property: "og:title", content: "Aimbot — Panther Patches" },
      { property: "og:description", content: "Toggle your Aim, Texture, Holo Arma and Settings patches." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Patches,
});

type Item = { name: string; file: string };
const TABS: { id: string; label: string; items: Item[] }[] = [
  {
    id: "aim",
    label: "AIM",
    items: [
      { name: "AIM DRAG", file: "AIM_DRAG.3105" },
      { name: "AIM CABEZA", file: "Aimbot_Cabeza_Syz_Vip_x_Cherry_👹.3105" },
      { name: "AIM PECHO", file: "AIMBOT_PECHO-.3105" },
    ],
  },
  { id: "texture", label: "TEXTURE", items: [] },
  { id: "holo", label: "HOLO ARMA", items: [] },
  { id: "settings", label: "SETTINGS", items: [] },
];

const FREE_FIRE_URL = "freefire://";
const FREE_FIRE_ERROR = "This app requires Free Fire. Please install Free Fire to continue.";

function Patches() {
  const [tab, setTab] = useState("aim");
  const [on, setOn] = useState<Record<string, boolean>>({});
  const [launchError, setLaunchError] = useState(false);
  const launchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const current = TABS.find((t) => t.id === tab)!;

  useEffect(() => {
    const cancelLaunchCheck = () => {
      if (launchTimer.current) clearTimeout(launchTimer.current);
    };

    document.addEventListener("visibilitychange", cancelLaunchCheck);
    window.addEventListener("pagehide", cancelLaunchCheck);
    return () => {
      cancelLaunchCheck();
      document.removeEventListener("visibilitychange", cancelLaunchCheck);
      window.removeEventListener("pagehide", cancelLaunchCheck);
    };
  }, []);

  const togglePatch = (file: string, active: boolean) => {
    if (launchTimer.current) clearTimeout(launchTimer.current);
    setLaunchError(false);

    if (active) {
      setOn((state) => ({ ...state, [file]: false }));
      return;
    }

    setOn((state) => ({ ...state, [file]: true }));
    window.location.href = FREE_FIRE_URL;

    launchTimer.current = setTimeout(() => {
      if (document.visibilityState === "visible") {
        setOn((state) => ({ ...state, [file]: false }));
        setLaunchError(true);
      }
    }, 1800);
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <img src={bg} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-overlay" />
      <div className="relative mx-auto flex min-h-screen max-w-md flex-col px-3 pb-6 pt-6">
        <nav aria-label="Patch categories" className="glass flex gap-1 overflow-x-auto rounded-2xl p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setTab(t.id);
                setLaunchError(false);
              }}
              aria-pressed={tab === t.id}
              className={`flex-1 whitespace-nowrap rounded-xl px-1.5 py-2 text-[11px] font-bold tracking-wide transition-colors tab-glow ${
                tab === t.id ? "tab-pill text-tab-ink" : "text-tab-blue-soft hover:text-tab-blue"
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {launchError && (
          <div
            role="alert"
            className="glass mt-3 flex items-start gap-2 rounded-2xl border-destructive/60 p-3 text-xs leading-relaxed text-foreground"
          >
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
            <span className="flex-1">{FREE_FIRE_ERROR}</span>
            <button
              type="button"
              aria-label="Dismiss Free Fire message"
              onClick={() => setLaunchError(false)}
              className="rounded-md p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        )}

        {current.items.length === 0 ? (
          <div className="glass mt-4 rounded-3xl p-6 text-center text-sm text-muted-foreground">No files yet</div>
        ) : (
          <ul className="mt-4 flex flex-col gap-2.5">
            {current.items.map((item) => {
              const active = !!on[item.file];
              return (
                <li
                  key={item.file}
                  className="glass flex items-center gap-2.5 rounded-2xl border-tab-blue/45 px-3 py-3 shadow-switch"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/20">
                    <Crosshair className="h-4 w-4 text-primary" aria-hidden="true" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">{item.name}</span>
                    <span className={`text-xs ${active ? "text-tab-blue" : "text-muted-foreground"}`}>
                      {active ? "Activated" : "Deactivated"}
                    </span>
                  </span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={active}
                    aria-label={`${active ? "Deactivate" : "Activate"} ${item.name}`}
                    onClick={() => togglePatch(item.file, active)}
                    className={`relative h-7 w-12 shrink-0 rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
                      active ? "border-tab-blue bg-primary shadow-switch-on" : "border-switch-off-border bg-switch-off"
                    }`}
                  >
                    <span
                      aria-hidden="true"
                      className={`absolute left-0.5 top-0.5 h-5.5 w-5.5 rounded-full bg-primary-foreground shadow-switch-knob transition-transform ${
                        active ? "translate-x-5" : "translate-x-0"
                      }`}
                    />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </main>
  );
}
